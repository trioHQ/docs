const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3005;

app.use(cors());
app.use(express.json());

const CLIENT_ID = "TOUR_CLIENT_ID";
const CLIENT_SECRET = "YOUR_CLIENT_SECRET";


app.post("/create-session", async (req, res) => {

  try {

    const {
      type,
      cpf,
      amount
    } = req.body;

    if (!type) {
      return res.status(400).json({
        error: "type é obrigatório"
      });
    }

    if (!cpf) {
      return res.status(400).json({
        error: "cpf é obrigatório"
      });
    }

    if (!amount) {
      return res.status(400).json({
        error: "amount é obrigatório"
      });
    }

    // console.log('valor', amount)
    const auth = Buffer
      .from(`${CLIENT_ID}:${CLIENT_SECRET}`)
      .toString("base64");

    const body = {
      transaction: {
        tax_number: cpf,
        name: "ARTHUR ALCANTARA DE ANDRADE",
        amount: amount,
            available_withdraw_amount: 100000,
        external_id: crypto.randomUUID(),
        description: `${type} created via SDK`,
        // redirect_url: "http://localhost:8080/sdk.html"
      },

      receiver: {
        virtual_account_id:
          "0196f804-df75-14d8-f53f-5b837579f17b"
      },

      options: {
        session_type: type,
   
        expiration_in_seconds: 86400,
        allow_other_pix_key: false,

        theme: {
          colors: {
            backdrop_color: "#ffffff",
            button_color: "#f6df69",
            button_label_color: "#000000",
            link_color: "#426b55",
            navbar_action_color: "#ffffff",
            navbar_color: "#426b55"
          },

          logo_url:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-3fKY7RuvPhXZB9wDww-Gd3nDZasVZjdQVw&s"
        }
      }
    };

    console.log('body', body)

    const response = await fetch(
      "https://api.sandbox.trio.com.br/checkout/sessions",
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json"
        },

        body: JSON.stringify(body)
      }
    );

    const data = await response.json();

    console.log("Resposta Trio:", data);

    if (!data.data) {

      return res.status(400).json({
        error: "Erro ao criar sessão",
        trio_response: data
      });

    }

    return res.json({
      session_id: data.data.id
    });

  } catch (error) {

    console.error("Erro:", error);

    return res.status(500).json({
      error: "Erro interno"
    });

  }

});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});